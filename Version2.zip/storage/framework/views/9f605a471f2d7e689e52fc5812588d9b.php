<?php $__env->startSection('contenu'); ?>
    <div class="card">
        <div class="card-header">
        <h5 class="card-title">Liste Livreur</h5>
        </div>
        <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-hover" id="livreur">
                <thead>
                    <tr>
                    <th>ID</th>
                    <th>Matricule</th>
                    <th>Livreur</th>
                    <th>Boulangerie</th>
                    <th>Telephone</th>
                    <th class="text-center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $livreur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr> 
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td><?php echo e($livreur->matricule); ?> </td>
                    <td><?php echo e($livreur->prenom); ?> <?php echo e($livreur->nom); ?></td>
                    <td><span class="badge badge-success"><?php echo e($livreur->structures->nom_complet); ?></span> </td>
                    <td>
                        <?php echo e($livreur->telephone); ?>

                    <td class="text-center">
                        <a href="<?php echo e(route('Livreur.edition',['livreur'=>$livreur->id])); ?>" class="btn btn-link"><i class="fas fa-edit"></i></a>
                        <button class="btn btn-link" id="supprimer"><i class="fas fa-trash"></i></button>
                    </td>
                    </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
        </div>
        </div>
      
        <script async>
            $(document).ready(function(){

                $('#livreur').DataTable();


                })
        </script> 
<?php $__env->stopSection(); ?>
 


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/livreur/index.blade.php ENDPATH**/ ?>