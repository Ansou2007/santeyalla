
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>Boulangerie</title>

<link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">

<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500;1,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('plugins/feather/feather.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('plugins/icons/flags/flags.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/datatables.min.css')); ?>">
<link href="<?php echo e(asset('plugins/toastr/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>

</head>
<body>

<div class="main-wrapper">

    
<?php echo $__env->make('components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!--debut content-->
<div class="page-wrapper">
<div class="content container-fluid">
<div class="row">
<div class="col-sm-12">

<?php echo $__env->yieldContent('contenu'); ?>

</div>
</div>
</div>
</div>
<!--Fin Content-->

<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/layouts/master.blade.php ENDPATH**/ ?>