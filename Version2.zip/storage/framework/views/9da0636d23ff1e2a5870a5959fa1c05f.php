<?php $__env->startSection('contenu'); ?>
<div class="card comman-shadow">
    <div class="card-body">
    <form method="post">
        <?php echo csrf_field(); ?>
    <div class="row">
    <div class="col-12">
    <h5 class="form-title student-info">Information Ventilation <span><a href="javascript:;"><i class="feather-more-vertical"></i></a></span></h5>
    </div>    
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="">Livreur</label>
                    <select class="form-control <?php $__errorArgs = ['livreur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="livreur_id" >
                        <option value="" selected disabled>Selectionnez</option>
                        <?php $__currentLoopData = $livreurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livreur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($livreur->id); ?>"><?php echo e($livreur->prenom); ?> <?php echo e($livreur->nom); ?> (<?php echo e($livreur->structures->nom_complet); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['livreur_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="text-danger"><?php echo e($message); ?></span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="">Date ventilation</label>
        <input type="date" class="form-control <?php $__errorArgs = ['date_ventilation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="date_ventilation">
        <?php $__errorArgs = ['date_ventilation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>

    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="">Ventile</label>
        <input type="number" class="form-control <?php $__errorArgs = ['ventile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="ventile" name="ventile" id="ventile">
        <?php $__errorArgs = ['ventile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>

    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="exampleInputEmail1">Non Ventile</label>
        <input type="number" class="form-control <?php $__errorArgs = ['non_ventile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="non_ventile" placeholder="non ventile" id="non_ventile">
        <?php $__errorArgs = ['non_ventile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>

    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="">Retour</label>
        <input type="number" class="form-control <?php $__errorArgs = ['retour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="retour" name="retour" id="retour">
        <?php $__errorArgs = ['retour'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>

    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="exampleInputEmail1">Prix Unitaire</label>
        <input type="number" class="form-control <?php $__errorArgs = ['pu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Prix Unitaire" name="pu" id="pu" >
        <?php $__errorArgs = ['pu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>
    <div class="col-12 col-sm-6">
        <div class="form-group local-forms">
            <label for="">Montant Versé</label>
            <input type="number" class="form-control <?php $__errorArgs = ['montant_verse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="Montant Versé" name="montant_verse" id="mtn_verse" value="0" >
        </div>
    </div> 
    <div class="col-12 col-sm-6">
        <div class="form-group local-forms">
            <label for="exampleInputEmail1">Location</label>
            <input type="number" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="location" id="location" value="0">
            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-12 col-sm-6">
        <div class="form-group local-forms">
            <label for="exampleInputEmail1">Montant A Versé</label>
            <input type="hidden" class="form-control <?php $__errorArgs = ['montant_a_verse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="montant_a_verse" id="montant_a_verser" disabled>
            <?php $__errorArgs = ['montant_a_verse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="">Qté Vendue</label>
        <input type="hidden" class="form-control <?php $__errorArgs = ['qte_vendue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="Qté vendue" name="qte_vendue" id="qte_vendue" >
        <?php $__errorArgs = ['qte_vendue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    </div>

    

       
    
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
        <label for="">Reliquat</label>
        <input type="hidden" class="form-control <?php $__errorArgs = ['reliquat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"   name="reliquat" id="reliquat" disabled>
    </div>
    </div>
    <div class="col-12">
    <div class="student-submit">
    <button type="submit" class="btn btn-primary">Enregistrer</button>
    <button id="btn_verify" class="btn btn-warning">Verifier</button>
    <a href="<?php echo e(route('Ventilation.index')); ?>" class="btn btn-danger">retour</a>
    </div>
    </div>
    </div>
    </form>
    </div>
    </div>
    <script>
        $(document).ready(function(e){
            /* calcul */
        function calcul() {
            var ventile = parseInt($('#ventile').val());
            var nventile = parseInt($('#non_ventile').val());
            var retour = parseInt($('#retour').val());
            var prix = parseInt($('#pu').val());
            var location = parseInt($('#location').val());
            var mtn_verse = parseInt($('#mtn_verse').val());
            var qte_vendue = ventile - (nventile + retour);
            var montant_vendue = (qte_vendue * prix) - location;
            $('#qte_vendue').val(qte_vendue);
            $('#montant_a_verser').val(montant_vendue);
            var reliquat = montant_vendue - mtn_verse;
            $('#reliquat').val(reliquat);
            console.log('Qté Vendue :' + qte_vendue);
            console.log('Montant Vendue : ' + montant_vendue);
            console.log('Reliquat : ' + reliquat);

        }
        
        $('#pu').on('keyup',function(e){
            e.preventDefault();
            calcul();
        });
        $('#location').on('keyup',function(e){
            e.preventDefault();
            calcul();
        });

        $('#mtn_verse').on('keyup',function(e){
            e.preventDefault();
            calcul();
        });

        // Bouton verification
        $('#btn_verify').click(function(e){
            e.preventDefault();
            calcul();
            var location = $('#location').val();
            var montant = $('#montant_a_verser').val();
            var qte = $('#qte_vendue').val();
            var reliquat = $('#reliquat').val();
            swal.fire({
                icon: 'info',
                toast: true,
                title: 'Verification',
                text: 'Vendue = ' + qte + ' Montant = ' + montant + ' Reliquat = ' + reliquat
            });
        });

        })
    </script>
    <?php if(session()->has('Message')): ?>
    <script>
        $(document).ready(function(e){
            Swal.fire('Ventilation',"<?php echo e(session()->get('Message')); ?>",'info');
        })
    </script>
        
    <?php endif; ?>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/ventilation/ajout.blade.php ENDPATH**/ ?>