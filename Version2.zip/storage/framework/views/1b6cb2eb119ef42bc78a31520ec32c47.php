<?php $__env->startSection('contenu'); ?>
<div class="card comman-shadow">
    <div class="card-body">
    <form method="post">
        <?php echo csrf_field(); ?>
    <div class="row">
    <div class="col-12">
    <h5 class="form-title student-info">Information Utilisateur <span><a href="javascript:;"><i class="feather-more-vertical"></i></a></span></h5>
    </div>
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
    <label>Prenom <span class="login-danger">*</span></label>
    <input class="form-control <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="prenom" name="prenom">
    </div>
    </div>
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
    <label>Nom <span class="login-danger">*</span></label>
    <input class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="nom" name="nom">
    </div>
    </div>
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
    <label>Email <span class="login-danger">*</span></label>
    <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" placeholder="email" name="email">
    </div>
    </div>
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
    <label>Telephone </label>
    <input class="form-control <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" placeholder="telephone" name="telephone">
    </div>
    </div>
    <div class="col-12 col-sm-6">
    <div class="form-group local-forms">
    <label>Role<span class="login-danger">*</span></label>
    <select class="form-control" name="role" >
    <option  disabled>Role </option>
    <option value="Admin">Administrateur</option>
    <option value="Ventileur">Ventileur</option>
    <option value="Livreur" selected>Livreur</option>
    </select>
    </div>
    </div>
    <div class="col-12 col-sm-4">
    <div class="form-group local-forms">
    <label>status <span class="login-danger">*</span></label>
    <select class="form-control" name="status">
    <option  disabled>Status</option>
    <option value="Actif" selected>Actif</option>
    <option value="Inactif">inactif</option>
    </select>
    </div>
    </div>
    
    <div class="col-12 col-sm-4">
    <div class="form-group local-forms">
    <label>Adresse </label>
    <input class="form-control" type="text" placeholder="Adresse" name="adresse">
    </div>
    </div>
    
    <div class="col-12 col-sm-4">
    <div class="form-group students-up-files">
    <div class="uplod">
    <label class="file-upload image-upbtn mb-0">
    Choisir photo <input type="file" name="photo">
    </label>
    </div>
    </div>
    </div>
    <div class="col-12">
    <div class="student-submit">
    <button type="submit" class="btn btn-primary">Enregistrer</button>
    <a href="<?php echo e(route('Utilisateur.index')); ?>" class="btn btn-danger">retour</a>
    </div>
    </div>
    </div>
    </form>
    </div>
    </div>
     <?php if(session()->has('Message')): ?>
     <script>
        $(document).ready(function(){

            Swal.fire('Message',"<?php echo e(session()->get('Message')); ?>",'info');
            //alert('utilisateur ajouté avec success');
        })
        
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/utilisateur/ajout.blade.php ENDPATH**/ ?>