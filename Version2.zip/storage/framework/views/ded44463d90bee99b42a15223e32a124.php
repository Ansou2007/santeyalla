<?php $__env->startSection('contenu'); ?>
    <h1>bienvenue sur la plateforme</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/dashboard.blade.php ENDPATH**/ ?>