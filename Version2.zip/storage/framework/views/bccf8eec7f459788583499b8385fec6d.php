<?php $__env->startSection('contenu'); ?>
    <div class="card">
        <div class="card-header">
        <h5 class="card-title">Liste Utilisateur</h5>
        </div>
        <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-hover" id="utilisateur">
                <thead>
                    <tr>
                    <th>ID</th>
                    <th>Nom Complet</th>
                    <th>Email</th>
                    <th>Boulangerie</th>
                    <th>Telephone</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th class="text-center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $utilisateur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utilisateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr> 
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td><?php echo e($utilisateur->prenom); ?> <?php echo e($utilisateur->nom); ?></td>
                    <td><?php echo e($utilisateur->email); ?> </td>
                    <td><span class="badge badge-info"><?php echo e($utilisateur->structures->nom_complet); ?></span> </td>
                    <td> <?php echo e($utilisateur->telephone); ?></td>
                    <td>
                        <span class="badge badge-success"><?php echo e($utilisateur->role); ?></span>
                     </td>
                    <td>
                        <?php if($utilisateur->status == "Actif"): ?>
                            <span class="badge badge-success"><?php echo e($utilisateur->status); ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger"><?php echo e($utilisateur->status); ?></span>
                        
                        <?php endif; ?>                            
                     </td>
                    <td class="text-center">
                        <a href="" class="btn btn-link"><i class="fas fa-edit"></i></a>
                        <button class="btn btn-link" id="supprimer"><i class="fas fa-trash"></i></button>
                    </td>
                    </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>
        </div>
        </div>
        
        <script>
            $(document).ready(function(){
                $('#utilisateur').DataTable();
           /*      
                const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
                })
                Toast.fire({
                icon: 'success',
                title: 'Signed in successfully'
                }) */

                })
        </script> 
       
<?php $__env->stopSection(); ?>
 


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/utilisateur/index.blade.php ENDPATH**/ ?>