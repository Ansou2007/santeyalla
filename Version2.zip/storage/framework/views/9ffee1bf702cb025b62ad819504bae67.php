<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Livreur')): ?>
    
<div class="sidebar-inner slimscroll">
<div id="sidebar-menu" class="sidebar-menu">
<ul>
<li class="menu-title">
<span>Menu</span>
</li>

<li class="submenu active">
<a href="#"><i class="feather-grid active"></i> <span>Tableau de Bord</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="">Livreur Dashboard</a></li>
</ul>
</li>

<li class="submenu">
<a href="#"><i class="fas fa-graduation-cap"></i> <span>Situation</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="">Mes Ventilations</a></li>
<li><a href=""><i class="fas fa-search"></i>Mes Commissions</a></li>
<li><a href=""><i class="fas fa-plus"></i>Mon Salaire</a></li>
</ul>
</li>
</ul>
</div>
</div>
<?php endif; ?><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/components/livreur.blade.php ENDPATH**/ ?>