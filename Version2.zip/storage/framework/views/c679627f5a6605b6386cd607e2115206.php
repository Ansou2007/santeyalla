<!--Debut Sidebar Admin-->
<div class="sidebar" id="sidebar">
 
   <!--Menu Administrateur -->
   <?php echo $__env->make('components.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!--Menu Ventileur -->
   <?php echo $__env->make('components.ventileur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!--Menu Livreur -->
   <?php echo $__env->make('components.livreur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
   

    </div>
    <!--Fin Sidebar--><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/components/sidebar.blade.php ENDPATH**/ ?>