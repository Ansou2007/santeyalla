<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ventileur dashboard</title>
</head>
<body>
    <h1>ventileur Dashboard</h1>
</body>
</html><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/ventileur/index.blade.php ENDPATH**/ ?>