
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>Error 404</title>

<link rel="shortcut icon" href="assets/img/favicon.png">

<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500;1,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/feather.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/flags.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body class="error-page">

<div class="main-wrapper">
<div class="error-box">
<h1>419</h1>
<h3 class="h2 mb-3"><i class="fas fa-exclamation-triangle"></i> Oops! Page Expirée !</h3>
<p class="h4 font-weight-normal">La page a expirée</p>
<a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">Retour à l'accueil</a>
</div>
</div>


<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</html><?php /**PATH /Users/macair/Desktop/Laravel Project/santeyalla/resources/views/errors/419.blade.php ENDPATH**/ ?>