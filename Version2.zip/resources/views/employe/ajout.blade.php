@extends('layouts.master')

@section('contenu')
    <h1>Ajout salaire</h1>
@endsection