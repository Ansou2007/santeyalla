@extends('layouts.master')

@section('contenu')
    <h1>employe</h1>
@endsection