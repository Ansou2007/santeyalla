
@extends('layouts.master')

@section('contenu')
    <h1>bienvenue sur la plateforme</h1>
@endsection
