<!--Debut Sidebar Admin-->
<div class="sidebar" id="sidebar">
 
   <!--Menu Administrateur -->
   @include('components.admin')
   <!--Menu Ventileur -->
   @include('components.ventileur')
   <!--Menu Livreur -->
   @include('components.livreur')
 
   

    </div>
    <!--Fin Sidebar-->