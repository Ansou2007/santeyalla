@extends('layouts.master')

@section('contenu')
    <h1>Dashboard ventileur</h1>
@endsection