@extends('layouts.master')

@section('contenu')
    <h1>Dashboard livreur</h1>
@endsection