@extends('layouts.master')

@section('contenu')
    <h1>edition Utilisateur</h1>
@endsection