@extends('layouts.master')

@section('contenu')
    <h1>detail Utilisateur</h1>
@endsection